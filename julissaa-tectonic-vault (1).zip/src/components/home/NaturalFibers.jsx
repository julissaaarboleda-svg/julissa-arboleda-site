import { motion } from 'framer-motion';

const fibers = [
  {
    name: 'Hemp',
    image: 'https://julissaa.com/cdn/shop/files/Hemp.webp?v=1772843466&width=600',
    description: "One of the most sustainable fibers in the world. Grows without pesticides, improves soil health, and uses minimal water. Gets softer with every wash. Naturally antimicrobial and UV-resistant. Strong, breathable, and built to last decades.",
  },
  {
    name: 'Organic Cotton',
    image: 'https://julissaa.com/cdn/shop/files/Cotton.jpg?v=1772843537&width=600',
    description: "Grown without synthetic pesticides or fertilizers. Soft, breathable, and hypoallergenic. Regulates temperature naturally—cool in summer, warm in winter. Certified organic means better conditions for farmers and healthier soil. Biodegradable and endlessly recyclable.",
  },
  {
    name: 'Linen',
    image: 'https://julissaa.com/cdn/shop/files/Linen.webp?v=1772843790&width=600',
    description: "Made from flax plants that thrive in poor soil and require little water. The ultimate breathable fabric—wicks moisture and dries quickly. Becomes softer and more beautiful with age. Naturally wrinkle-prone (that's the charm). Antibacterial and hypoallergenic.",
  },
];

export default function NaturalFibers() {
  return (
    <section className="border-t border-accent/40">
      <div className="max-w-[1440px] mx-auto px-6 md:px-12 py-24 md:py-32">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <h2 className="font-display text-3xl md:text-4xl font-light tracking-[0.02em]">
            Natural Fibers
          </h2>
          <div className="h-[0.5px] bg-accent/60 mt-8" />
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 md:gap-16">
          {fibers.map((fiber, index) => (
            <motion.div
              key={fiber.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.15 }}
              className="group"
            >
              {/* Fiber image */}
              <div className="aspect-square overflow-hidden bg-secondary mb-6">
                <img
                  src={fiber.image}
                  alt={`${fiber.name} fabric texture`}
                  className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-700"
                />
              </div>
              <h3 className="font-display text-2xl font-light mb-4">{fiber.name}</h3>
              <p className="font-body text-sm text-muted-foreground leading-[1.8]">
                {fiber.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}