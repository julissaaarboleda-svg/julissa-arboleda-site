import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const BTS_VIDEO = 'https://cdn.shopify.com/videos/c/o/v/9c444c2f769c4db4a67648e554bb1b56.mp4';

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex flex-col md:flex-row">
      {/* Full-bleed BTS video — 60% on desktop, full width on mobile */}
      <div className="relative w-full md:w-[60%] h-[60vw] md:h-screen overflow-hidden bg-[#1a1a1a]">
        <video
          autoPlay
          muted
          loop
          playsInline
          className="absolute inset-0 w-full h-full object-cover"
        >
          <source src={BTS_VIDEO} type="video/mp4" />
        </video>
        {/* Subtle dark vignette on edges */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent to-black/10 pointer-events-none" />

        {/* Video caption overlay */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1 }}
          className="absolute bottom-8 left-8 flex flex-col gap-1"
        >
          <span className="text-[10px] font-body font-medium uppercase tracking-[0.3em] text-white/70">
            Behind the Scenes
          </span>
          <span className="text-[10px] font-body font-medium uppercase tracking-[0.3em] text-white/50">
            Houston, TX
          </span>
        </motion.div>
      </div>

      {/* Right text — 40% on desktop */}
      <div className="w-full md:w-[40%] flex flex-col justify-center px-8 md:px-16 lg:px-20 py-16 md:py-0 bg-background">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5, ease: [0.25, 0.1, 0.25, 1] }}
        >
          <p className="text-[11px] font-body font-medium uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Julissa Arboleda
          </p>

          <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-light leading-[1.1] tracking-[-0.01em] mb-8">
            The beauty in chaos.<br />
            The beauty in what remains.
          </h1>

          <p className="font-body text-sm text-muted-foreground leading-[1.8] mb-12 max-w-sm">
            Afro-Colombian designer. Small-batch production in Houston. Natural fibers. Intentional design.
          </p>

          <Link
            to="/women"
            className="inline-block px-12 py-4 bg-primary text-primary-foreground text-[11px] font-body font-medium uppercase tracking-[0.25em] hover:bg-primary/90 transition-all duration-500"
          >
            Shop Women
          </Link>
        </motion.div>
      </div>
    </section>
  );
}