import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const NYFW_VIDEO = 'https://media.base44.com/videos/public/6a205a86ef6e79a1362a7247/877455259_CopyofNewYorkFashionWeek1.mp4';

export default function NyfwSection() {
  return (
    <section className="max-w-[1440px] mx-auto px-6 md:px-12 py-24 md:py-32">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-20 items-center">
        {/* Video */}
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="aspect-video overflow-hidden bg-secondary relative"
        >
          <video
            src={NYFW_VIDEO}
            controls
            playsInline
            className="absolute inset-0 w-full h-full object-cover"
          />
        </motion.div>

        {/* Text */}
        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <p className="text-[11px] font-body font-medium uppercase tracking-[0.2em] text-muted-foreground mb-4">
            2016
          </p>
          <h2 className="font-display text-3xl md:text-4xl font-light tracking-[0.02em] mb-6">
            New York Fashion Week
          </h2>
          <p className="font-body text-sm text-muted-foreground leading-[1.8] mb-10 max-w-md">
            Watch our Suffocation collection debut at NYFW.
          </p>
          <Link
            to="/about"
            className="inline-block px-10 py-3.5 border border-foreground/20 text-[11px] font-body font-medium uppercase tracking-[0.25em] text-foreground hover:bg-foreground hover:text-background transition-all duration-500"
          >
            Read Our Story
          </Link>
        </motion.div>
      </div>
    </section>
  );
}