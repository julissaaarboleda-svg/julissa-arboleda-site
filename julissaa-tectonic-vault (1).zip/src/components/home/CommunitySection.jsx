import { useState } from 'react';
import { motion } from 'framer-motion';

export default function CommunitySection() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email) return;
    // Link to Julissa's Shopify newsletter signup with the email prefilled
    const shopifyUrl = `https://julissaa.com/#newsletter`;
    window.open(shopifyUrl, '_blank');
    setSubmitted(true);
  };

  return (
    <section className="border-t border-accent/40">
      <div className="max-w-[1440px] mx-auto px-6 md:px-12 py-24 md:py-32">
        <div className="max-w-xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="font-display text-3xl md:text-4xl font-light tracking-[0.02em] mb-6">
              Join Our Community
            </h2>
            <p className="font-body text-sm text-muted-foreground leading-[1.8] mb-10">
              Get 10% off your first order, plus early access to new releases and restocks. Made in small batches.
            </p>

            {submitted ? (
              <p className="font-display text-lg font-light text-foreground/70">
                Thank you — check your inbox.
              </p>
            ) : (
              <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-0 max-w-md mx-auto">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Your email address"
                  required
                  className="flex-1 px-5 py-4 bg-transparent border border-foreground/20 text-sm font-body text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:border-foreground/60 transition-colors sm:border-r-0"
                />
                <button
                  type="submit"
                  className="px-8 py-4 bg-primary text-primary-foreground text-[11px] font-body font-medium uppercase tracking-[0.25em] hover:bg-primary/90 transition-all duration-500 border border-primary whitespace-nowrap"
                >
                  Subscribe
                </button>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}