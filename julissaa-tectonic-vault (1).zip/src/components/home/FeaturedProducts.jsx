import { motion } from 'framer-motion';
import ProductCard from '../products/ProductCard';

export default function FeaturedProducts({ products }) {
  if (!products || products.length === 0) return null;

  return (
    <section className="max-w-[1440px] mx-auto px-6 md:px-12 py-24 md:py-32">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="mb-16"
      >
        <h2 className="font-display text-3xl md:text-4xl font-light tracking-[0.02em]">
          Featured products
        </h2>
        <div className="h-[0.5px] bg-accent/60 mt-8" />
      </motion.div>

      {/* Variable aspect ratio grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
        {products.map((product, index) => (
          <ProductCard
            key={product.id}
            product={product}
            variant={index === 0 ? 'default' : 'default'}
          />
        ))}
      </div>
    </section>
  );
}