import { motion, AnimatePresence } from 'framer-motion';
import { X, ShoppingBag } from 'lucide-react';

export default function SlideOutCart({ open, onClose }) {
  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-50 bg-foreground/20 backdrop-blur-sm"
            onClick={onClose}
          />

          {/* Cart panel */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className="fixed top-0 right-0 bottom-0 z-50 w-full max-w-md bg-background border-l border-accent/40 flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-8 py-6 border-b border-accent/40">
              <h2 className="font-display text-xl font-light tracking-[0.05em]">Your Cart</h2>
              <button onClick={onClose} className="text-foreground/60 hover:text-foreground transition-colors">
                <X className="w-5 h-5" strokeWidth={1.5} />
              </button>
            </div>

            {/* Empty state */}
            <div className="flex-1 flex flex-col items-center justify-center px-8">
              <ShoppingBag className="w-12 h-12 text-accent mb-6" strokeWidth={1} />
              <p className="font-display text-lg text-muted-foreground mb-2">Your cart is empty</p>
              <p className="text-sm text-muted-foreground/60 font-body text-center mb-8">
                Browse our collection and add pieces that speak to you.
              </p>
              <button
                onClick={onClose}
                className="px-8 py-3 bg-primary text-primary-foreground text-[11px] font-body font-medium uppercase tracking-[0.2em] hover:bg-primary/90 transition-colors"
              >
                Continue Shopping
              </button>
            </div>

            {/* Footer hint */}
            <div className="px-8 py-6 border-t border-accent/40">
              <p className="text-[11px] text-muted-foreground font-body text-center tracking-wider">
                Checkout is handled securely through our Shopify store
              </p>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}