import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ShoppingBag, Menu, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function Navbar({ cartCount = 0, onCartOpen }) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [location]);

  const links = [
    { to: '/', label: 'Home' },
    { to: '/women', label: 'Women' },
    { to: '/about', label: 'About' },
  ];

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled ? 'bg-background/95 backdrop-blur-md' : 'bg-transparent'
        }`}
      >
        <div className="max-w-[1440px] mx-auto px-6 md:px-12">
          <div className="flex items-center justify-between h-20 md:h-24">
            {/* Left nav links */}
            <div className="hidden md:flex items-center gap-10">
              {links.map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  className={`text-[11px] font-body font-medium uppercase tracking-[0.2em] transition-colors duration-300 hover:text-foreground/60 ${
                    location.pathname === link.to ? 'text-foreground' : 'text-foreground/80'
                  }`}
                >
                  {link.label}
                </Link>
              ))}
            </div>

            {/* Center logo */}
            <Link to="/" className="absolute left-1/2 -translate-x-1/2">
              <h1 className="font-display text-xl md:text-2xl font-light tracking-[0.15em] text-foreground">
                Julissa Arboleda
              </h1>
            </Link>

            {/* Right actions */}
            <div className="flex items-center gap-6 ml-auto">
              <button
                onClick={onCartOpen}
                className="relative group"
                aria-label="Open cart"
              >
                <ShoppingBag className="w-[18px] h-[18px] text-foreground/80 group-hover:text-foreground transition-colors duration-300" strokeWidth={1.5} />
                {cartCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-foreground text-background text-[9px] font-medium rounded-full flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </button>

              <button
                className="md:hidden"
                onClick={() => setMobileOpen(!mobileOpen)}
                aria-label="Toggle menu"
              >
                {mobileOpen ? (
                  <X className="w-5 h-5 text-foreground" strokeWidth={1.5} />
                ) : (
                  <Menu className="w-5 h-5 text-foreground" strokeWidth={1.5} />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Hairline rule */}
        <div className="h-[0.5px] bg-accent/60" />
      </nav>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-40 bg-background pt-24"
          >
            <div className="flex flex-col items-center gap-10 pt-16">
              {links.map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  className="font-display text-3xl font-light tracking-[0.1em] text-foreground hover:text-foreground/60 transition-colors"
                >
                  {link.label}
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}