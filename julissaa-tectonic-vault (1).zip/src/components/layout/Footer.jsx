import { useState } from 'react';
import { Link } from 'react-router-dom';

function FooterNewsletter() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email) return;
    window.open('https://julissaa.com/#newsletter', '_blank');
    setSubmitted(true);
  };

  if (submitted) {
    return <p className="text-sm font-body text-foreground/60 font-light">Thank you — check your inbox.</p>;
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-2">
      <input
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="Your email address"
        required
        className="w-full px-4 py-2.5 bg-transparent border border-foreground/20 text-sm font-body text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:border-foreground/50 transition-colors"
      />
      <button
        type="submit"
        className="px-6 py-2.5 bg-primary text-primary-foreground text-[11px] font-body font-medium uppercase tracking-[0.2em] hover:bg-primary/90 transition-colors"
      >
        Subscribe
      </button>
    </form>
  );
}

export default function Footer() {
  return (
    <footer className="border-t border-accent/40">
      <div className="max-w-[1440px] mx-auto px-6 md:px-12 py-16 md:py-24">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 md:gap-8">
          {/* Brand */}
          <div>
            <h3 className="font-display text-2xl font-light tracking-[0.1em] mb-6">
              Julissa Arboleda
            </h3>
            <p className="font-body text-sm text-muted-foreground leading-relaxed max-w-xs">
              Afro-Colombian designer. Small-batch production in Houston. Natural fibers. Intentional design.
            </p>
          </div>

          {/* Navigation */}
          <div>
            <p className="text-[11px] font-body font-medium uppercase tracking-[0.2em] text-muted-foreground mb-6">
              Navigate
            </p>
            <div className="flex flex-col gap-3">
              <Link to="/" className="text-sm font-body text-foreground/80 hover:text-foreground transition-colors">
                Home
              </Link>
              <Link to="/women" className="text-sm font-body text-foreground/80 hover:text-foreground transition-colors">
                Women
              </Link>
              <Link to="/about" className="text-sm font-body text-foreground/80 hover:text-foreground transition-colors">
                About
              </Link>
            </div>
          </div>

          {/* Community — email signup */}
          <div>
            <p className="text-[11px] font-body font-medium uppercase tracking-[0.2em] text-muted-foreground mb-6">
              Community
            </p>
            <p className="text-sm font-body text-foreground/80 leading-relaxed mb-5">
              Get 10% off your first order, plus early access to new releases and restocks.
            </p>
            <FooterNewsletter />
          </div>
        </div>

        <div className="h-[0.5px] bg-accent/40 mt-16 mb-8" />

        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-[11px] font-body text-muted-foreground tracking-wider">
            © {new Date().getFullYear()} Julissa Arboleda. All rights reserved.
          </p>
          <a
            href="https://julissaa.com"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[11px] font-body text-muted-foreground tracking-wider hover:text-foreground transition-colors"
          >
            julissaa.com
          </a>
        </div>
      </div>
    </footer>
  );
}