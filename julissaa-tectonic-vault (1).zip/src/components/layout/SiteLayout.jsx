import { Outlet } from 'react-router-dom';
import { useState } from 'react';
import Navbar from './Navbar';
import Footer from './Footer';
import SlideOutCart from '../cart/SlideOutCart';
import StyleAssistant from '../ai/StyleAssistant';

export default function SiteLayout() {
  const [cartOpen, setCartOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar onCartOpen={() => setCartOpen(true)} />
      <main className="flex-1">
        <Outlet />
      </main>
      <Footer />
      <SlideOutCart open={cartOpen} onClose={() => setCartOpen(false)} />
      <StyleAssistant />
    </div>
  );
}