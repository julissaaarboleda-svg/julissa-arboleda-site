import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const COLOR_MAP = {
  white: '#F5F5F0',
  black: '#1a1a1a',
  olive: '#556B2F',
};

export default function ProductCard({ product, variant = 'default' }) {
  const images = product.images || [];
  const colors = product.colors || [];
  const colorImageMap = product.color_image_map || {};

  const [selectedColor, setSelectedColor] = useState(colors[0] || null);
  const [hovered, setHovered] = useState(false);

  // Use color_image_map to pick the right image, fallback to index 0
  const colorIndex = selectedColor && colorImageMap[selectedColor] !== undefined
    ? colorImageMap[selectedColor]
    : 0;
  const primaryImage = images[colorIndex] || images[0];
  const hoverImage = images[colorIndex + 1] || images[1] || primaryImage;

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.7, ease: [0.25, 0.1, 0.25, 1] }}
    >
      <Link
        to={`/product/${product.id}`}
        className="group block"
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
      >
        {/* Image */}
        <div className="relative overflow-hidden bg-secondary aspect-[3/4]">
          {primaryImage && (
            <img
              src={primaryImage}
              alt={product.name}
              className={`absolute inset-0 w-full h-full object-cover transition-all duration-700 ease-out ${
                hovered ? 'scale-105 opacity-0' : 'scale-100 opacity-100'
              }`}
            />
          )}
          {hoverImage && (
            <img
              src={hoverImage}
              alt={`${product.name} detail`}
              className={`absolute inset-0 w-full h-full object-cover transition-all duration-700 ease-out ${
                hovered ? 'scale-100 opacity-100' : 'scale-105 opacity-0'
              }`}
            />
          )}
          {product.is_sold_out && (
            <div className="absolute top-4 left-4">
              <span className="text-[10px] font-body font-medium uppercase tracking-[0.2em] text-foreground/70 bg-background/80 backdrop-blur-sm px-3 py-1.5">
                Sold Out
              </span>
            </div>
          )}
        </div>
      </Link>

      {/* Info + color swatches */}
      <div className="mt-4 space-y-2.5">
        <Link to={`/product/${product.id}`}>
          <h3 className="font-display text-lg font-light tracking-[0.02em] text-foreground hover:text-foreground/70 transition-colors duration-300">
            {product.name}
          </h3>
          <p className="text-sm font-body font-light text-muted-foreground tracking-wide">
            ${product.price?.toFixed(2)} USD
          </p>
        </Link>

        {/* Color swatches */}
        {colors.length > 1 && (
          <div className="flex items-center gap-2 pt-0.5" onClick={(e) => e.preventDefault()}>
            {colors.map((color) => (
              <button
                key={color}
                title={color}
                onClick={() => setSelectedColor(color)}
                className={`w-4 h-4 border transition-all duration-200 ${
                  selectedColor === color
                    ? 'ring-1 ring-foreground ring-offset-1 ring-offset-background border-foreground'
                    : 'border-accent/60 hover:border-foreground/40'
                }`}
                style={{ backgroundColor: COLOR_MAP[color.toLowerCase()] || '#ccc' }}
                aria-label={color}
              />
            ))}
            <span className="text-[10px] font-body text-muted-foreground uppercase tracking-[0.1em] ml-1">
              {selectedColor}
            </span>
          </div>
        )}
      </div>
    </motion.div>
  );
}