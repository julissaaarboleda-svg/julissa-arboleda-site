import { useState } from 'react';
import { X, Ruler } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const measurements = [
  { size: 'XS', bust: '32–33"', waist: '24–25"', hips: '34–35"', us: '0–2' },
  { size: 'S',  bust: '34–35"', waist: '26–27"', hips: '36–37"', us: '4–6' },
  { size: 'M',  bust: '36–37"', waist: '28–29"', hips: '38–39"', us: '8–10' },
  { size: 'L',  bust: '38–39"', waist: '30–31"', hips: '40–41"', us: '12–14' },
  { size: 'XL', bust: '40–41"', waist: '32–33"', hips: '42–43"', us: '16–18' },
  { size: '2XL',bust: '42–44"', waist: '34–36"', hips: '44–46"', us: '20–22' },
  { size: '3XL',bust: '46–48"', waist: '38–40"', hips: '48–50"', us: '24–26' },
];

export default function SizeGuide() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="flex items-center gap-1.5 text-[11px] font-body font-medium uppercase tracking-[0.15em] text-muted-foreground hover:text-foreground transition-colors underline underline-offset-4"
      >
        <Ruler className="w-3.5 h-3.5" strokeWidth={1.5} />
        Size Guide
      </button>

      <AnimatePresence>
        {open && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-foreground/20 backdrop-blur-sm"
              onClick={() => setOpen(false)}
            />

            {/* Modal */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.3 }}
              className="fixed inset-x-4 md:inset-x-auto md:left-1/2 md:-translate-x-1/2 md:w-full md:max-w-2xl top-1/2 -translate-y-1/2 z-50 bg-background border border-accent/40 p-8"
            >
              {/* Header */}
              <div className="flex items-center justify-between mb-8">
                <h3 className="font-display text-2xl font-light tracking-[0.02em]">Size Guide</h3>
                <button
                  onClick={() => setOpen(false)}
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  <X className="w-5 h-5" strokeWidth={1.5} />
                </button>
              </div>

              {/* How to measure */}
              <div className="mb-8">
                <p className="text-[11px] font-body font-medium uppercase tracking-[0.2em] text-muted-foreground mb-3">
                  How to Measure
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm font-body text-muted-foreground leading-relaxed">
                  <p><strong className="text-foreground font-medium">Bust</strong><br />Measure around the fullest part of your chest, keeping the tape horizontal.</p>
                  <p><strong className="text-foreground font-medium">Waist</strong><br />Measure around your natural waistline, the narrowest part of your torso.</p>
                  <p><strong className="text-foreground font-medium">Hips</strong><br />Measure around the fullest part of your hips, about 8" below your waistline.</p>
                </div>
              </div>

              <div className="h-[0.5px] bg-accent/40 mb-8" />

              {/* Size table */}
              <div className="overflow-x-auto">
                <table className="w-full text-sm font-body">
                  <thead>
                    <tr className="border-b border-accent/40">
                      <th className="text-left py-3 pr-6 text-[11px] font-medium uppercase tracking-[0.15em] text-muted-foreground">Size</th>
                      <th className="text-left py-3 pr-6 text-[11px] font-medium uppercase tracking-[0.15em] text-muted-foreground">Bust</th>
                      <th className="text-left py-3 pr-6 text-[11px] font-medium uppercase tracking-[0.15em] text-muted-foreground">Waist</th>
                      <th className="text-left py-3 pr-6 text-[11px] font-medium uppercase tracking-[0.15em] text-muted-foreground">Hips</th>
                      <th className="text-left py-3 text-[11px] font-medium uppercase tracking-[0.15em] text-muted-foreground">US Size</th>
                    </tr>
                  </thead>
                  <tbody>
                    {measurements.map((row, i) => (
                      <tr key={row.size} className={`border-b border-accent/20 ${i % 2 === 0 ? '' : 'bg-secondary/30'}`}>
                        <td className="py-3 pr-6 font-medium text-foreground">{row.size}</td>
                        <td className="py-3 pr-6 text-muted-foreground">{row.bust}</td>
                        <td className="py-3 pr-6 text-muted-foreground">{row.waist}</td>
                        <td className="py-3 pr-6 text-muted-foreground">{row.hips}</td>
                        <td className="py-3 text-muted-foreground">{row.us}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <p className="mt-6 text-xs font-body text-muted-foreground/70 leading-relaxed">
                Our garments are cut with ease in mind. If you're between sizes, size up for a more relaxed drape. Natural fibers like linen soften and relax with wear.
              </p>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}