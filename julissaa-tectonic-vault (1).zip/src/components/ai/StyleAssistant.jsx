import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Send, Loader2, Sparkles, ImagePlus, Image } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const SYSTEM_CONTEXT = `You are "Style Me" — Julissa Arboleda's AI personal stylist on her fashion brand website. Julissa is an Afro-Colombian designer based in Houston, TX creating minimalist, sensual clothing from natural fibers (hemp, organic cotton, linen).

Her current collection:
- Coraza Crop Vest ($200) — sleeveless turtleneck, structured bodice, organic cotton, sizes XS–3XL, colors: White, Black
- Distressed Crop Top ($175) — raw frayed edges, lace-up back, 100% linen, sizes XS–2XL, colors: Black, White
- Giselle Linen Trousers ($300) — high-waisted wide-leg, 100% linen, 35" inseam, sizes S–2XL, colors: White, Black
- La Raíz Skirt ($330) — high-waisted midi, gathered volume, side pockets, 100% linen, sizes XS–2XL, colors: Black, Olive, White
- Palenque Trousers ($380) — wide-leg, hemp/cotton blend, gold chain hardware, 35" inseam, sizes XS–2XL, color: Black (sold out)
- The Off Duty Dress ($330) — long-sleeve turtleneck, back slit, organic cotton, sizes XS–3XL, colors: Black, White

Size guide:
XS: Bust 32–33", Waist 24–25", Hips 34–35" (US 0–2)
S: Bust 34–35", Waist 26–27", Hips 36–37" (US 4–6)
M: Bust 36–37", Waist 28–29", Hips 38–39" (US 8–10)
L: Bust 38–39", Waist 30–31", Hips 40–41" (US 12–14)
XL: Bust 40–41", Waist 32–33", Hips 42–43" (US 16–18)
2XL: Bust 42–44", Waist 34–36", Hips 44–46" (US 20–22)
3XL: Bust 46–48", Waist 38–40", Hips 48–50" (US 24–26)

Your role:
1. Help customers find their correct size based on measurements
2. Look at uploaded photos of them or their wardrobe and recommend which Julissa pieces would complement their style
3. Help them style Julissa's pieces with their existing wardrobe
4. Answer questions about fabrics, care, and fit
5. Suggest complete looks using Julissa's pieces

Tone: Warm, confident, knowledgeable. Like a stylish friend, not a chatbot. Keep responses concise. When someone uploads a photo, analyze their style/body and recommend specific pieces from the collection that would suit them best.`;

const QUICK_PROMPTS = [
  { label: 'Find my size', text: 'I need help finding my size. Can you help me?' },
  { label: 'Style my wardrobe', text: 'I want to know which pieces would work with my existing wardrobe.' },
  { label: 'Build a look', text: 'Help me build a complete outfit from the collection.' },
];

export default function StyleAssistant() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: "I'm **Style Me** — your personal AI stylist for Julissa Arboleda's collection. I can help you find your size, style pieces with your wardrobe, or analyze a photo of you to recommend the perfect look.\n\nUpload a photo or ask me anything to get started.",
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [uploadedImage, setUploadedImage] = useState(null); // { url, preview }
  const [uploadingImage, setUploadingImage] = useState(false);
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingImage(true);
    const preview = URL.createObjectURL(file);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setUploadedImage({ url: file_url, preview });
    setUploadingImage(false);
  };

  const sendMessage = async (overrideText) => {
    const text = overrideText || input.trim();
    if ((!text && !uploadedImage) || loading) return;

    const imageUrl = uploadedImage?.url;
    const imagePreview = uploadedImage?.preview;

    const userMessage = {
      role: 'user',
      content: text || 'Here is a photo of me / my style — what pieces from the collection would work for me?',
      imagePreview,
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setUploadedImage(null);
    setLoading(true);

    const conversationHistory = [...messages, userMessage]
      .filter((m) => !m.imagePreview || m === userMessage)
      .map((m) => `${m.role === 'user' ? 'Customer' : 'Assistant'}: ${m.content}`)
      .join('\n');

    const prompt = `${SYSTEM_CONTEXT}\n\nConversation:\n${conversationHistory}\n\nRespond as the stylist. Be warm and specific. If an image was shared, analyze the style/body type and recommend specific pieces. Keep it 3–5 sentences max.`;

    let reply;
    if (imageUrl) {
      reply = await base44.integrations.Core.InvokeLLM({
        prompt,
        file_urls: [imageUrl],
        model: 'claude_sonnet_4_6',
      });

      // Also generate a visual outfit image
      const outfitImagePrompt = await base44.integrations.Core.InvokeLLM({
        prompt: `Based on this person's photo and Julissa Arboleda's minimalist natural-fiber collection, create a short image generation prompt (2 sentences max) for a fashion editorial showing how they would look in a recommended Julissa piece. Be specific about the garment, color, and styling. Return ONLY the image prompt, nothing else.`,
        file_urls: [imageUrl],
        model: 'claude_sonnet_4_6',
      });

      const outfitImage = await base44.integrations.Core.GenerateImage({
        prompt: `High-end fashion editorial photograph, minimalist natural linen clothing by Afro-Colombian designer. ${outfitImagePrompt} Warm alabaster and obsidian tones, dramatic chiaroscuro lighting, medium format film aesthetic. No text, no logos.`,
      });

      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: reply },
        { role: 'assistant', content: '✦ Here is how that look could come together:', generatedImage: outfitImage.url },
      ]);
    } else {
      reply = await base44.integrations.Core.InvokeLLM({ prompt });
      setMessages((prev) => [...prev, { role: 'assistant', content: reply }]);
    }

    setLoading(false);
  };

  const handleKey = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <>
      {/* Floating button with label */}
      <div className="fixed bottom-6 right-6 z-40 flex items-center gap-3">
        <AnimatePresence>
          {!open && (
            <motion.span
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              className="bg-background border border-accent/60 px-3 py-1.5 text-[11px] font-body font-medium uppercase tracking-[0.15em] text-foreground shadow-sm whitespace-nowrap"
            >
              Style Me
            </motion.span>
          )}
        </AnimatePresence>
        <motion.button
          onClick={() => setOpen(!open)}
          className="w-14 h-14 bg-primary text-primary-foreground flex items-center justify-center shadow-lg hover:bg-primary/90 transition-colors duration-300"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          aria-label="Open Style Me assistant"
        >
          <AnimatePresence mode="wait">
            {open ? (
              <motion.div key="close" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }} transition={{ duration: 0.2 }}>
                <X className="w-5 h-5" strokeWidth={1.5} />
              </motion.div>
            ) : (
              <motion.div key="open" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }} transition={{ duration: 0.2 }}>
                <Sparkles className="w-5 h-5" strokeWidth={1.5} />
              </motion.div>
            )}
          </AnimatePresence>
        </motion.button>
      </div>

      {/* Chat panel */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.25 }}
            className="fixed bottom-24 right-6 z-40 w-[calc(100vw-3rem)] max-w-sm bg-background border border-accent/40 shadow-2xl flex flex-col"
            style={{ height: '520px' }}
          >
            {/* Header */}
            <div className="px-5 py-4 border-b border-accent/40 bg-primary text-primary-foreground flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Sparkles className="w-4 h-4" strokeWidth={1.5} />
                <div>
                  <p className="font-display text-base font-light tracking-[0.05em]">Style Me</p>
                  <p className="text-[10px] font-body opacity-70 uppercase tracking-[0.15em]">AI Personal Stylist · Julissa Arboleda</p>
                </div>
              </div>
              <button onClick={() => setOpen(false)} className="opacity-60 hover:opacity-100 transition-opacity">
                <X className="w-4 h-4" strokeWidth={1.5} />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
              {messages.map((msg, i) => (
                <div key={i} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                  {msg.imagePreview && (
                    <img src={msg.imagePreview} alt="Uploaded" className="max-w-[80%] mb-2 object-cover" style={{ maxHeight: 160 }} />
                  )}
                  {msg.content && (
                    <div className={`max-w-[88%] px-4 py-3 text-sm font-body leading-[1.7] ${
                      msg.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-secondary text-foreground'
                    }`}>
                      {msg.content}
                    </div>
                  )}
                  {msg.generatedImage && (
                    <div className="mt-2 max-w-[88%]">
                      <img src={msg.generatedImage} alt="Generated outfit" className="w-full object-cover" />
                      <p className="text-[10px] font-body text-muted-foreground mt-1 tracking-wide">AI-generated style visualization</p>
                    </div>
                  )}
                </div>
              ))}

              {/* Quick prompts — show only at start */}
              {messages.length === 1 && (
                <div className="flex flex-col gap-2 pt-1">
                  {QUICK_PROMPTS.map((p) => (
                    <button
                      key={p.label}
                      onClick={() => sendMessage(p.text)}
                      className="text-left text-xs font-body text-foreground/70 border border-accent/60 px-3 py-2 hover:border-foreground/40 hover:text-foreground transition-colors"
                    >
                      {p.label} →
                    </button>
                  ))}
                </div>
              )}

              {loading && (
                <div className="flex justify-start">
                  <div className="bg-secondary px-4 py-3 flex items-center gap-2">
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-muted-foreground" />
                    <span className="text-xs text-muted-foreground font-body">styling...</span>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Uploaded image preview */}
            {uploadedImage && (
              <div className="px-4 pb-2 flex items-center gap-2">
                <img src={uploadedImage.preview} alt="preview" className="w-10 h-10 object-cover border border-accent/40" />
                <span className="text-xs font-body text-muted-foreground flex-1 truncate">Photo attached</span>
                <button onClick={() => setUploadedImage(null)} className="text-muted-foreground hover:text-foreground">
                  <X className="w-4 h-4" strokeWidth={1.5} />
                </button>
              </div>
            )}

            {/* Input */}
            <div className="px-4 py-3 border-t border-accent/40">
              <div className="flex gap-2 items-center">
                {/* Photo upload */}
                <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploadingImage}
                  className="w-9 h-9 border border-accent/60 flex items-center justify-center text-muted-foreground hover:text-foreground hover:border-foreground/40 transition-colors disabled:opacity-40 flex-shrink-0"
                  title="Upload a photo"
                >
                  {uploadingImage ? <Loader2 className="w-4 h-4 animate-spin" /> : <ImagePlus className="w-4 h-4" strokeWidth={1.5} />}
                </button>

                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKey}
                  placeholder="Ask about sizing, styling..."
                  className="flex-1 bg-transparent text-sm font-body text-foreground placeholder:text-muted-foreground/60 focus:outline-none px-3 py-2 border border-accent/40 focus:border-foreground/40 transition-colors min-w-0"
                />
                <button
                  onClick={() => sendMessage()}
                  disabled={(!input.trim() && !uploadedImage) || loading}
                  className="w-9 h-9 bg-primary text-primary-foreground flex items-center justify-center hover:bg-primary/90 transition-colors disabled:opacity-40 disabled:cursor-not-allowed flex-shrink-0"
                >
                  <Send className="w-4 h-4" strokeWidth={1.5} />
                </button>
              </div>
              <p className="text-[10px] font-body text-muted-foreground/50 mt-1.5 text-center">
                Upload a photo · AI will suggest an outfit + generate a visual
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}