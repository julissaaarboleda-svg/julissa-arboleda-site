import { motion } from 'framer-motion';

const ATELIER_IMAGE = 'https://media.base44.com/images/public/6a205a86ef6e79a1362a7247/50e92d31b_generated_e5689a7c.png';

const fadeUp = {
  initial: { opacity: 0, y: 30 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.7 },
};

export default function About() {
  return (
    <div className="pt-24 md:pt-28">
      {/* Hero */}
      <section className="max-w-[1440px] mx-auto px-6 md:px-12 pt-12 md:pt-20 pb-16">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="font-display text-4xl md:text-5xl lg:text-6xl font-light tracking-[0.02em] mb-8"
        >
          About
        </motion.h1>
        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="h-[0.5px] bg-accent/60 origin-left"
        />
      </section>

      {/* Tagline block */}
      <section className="bg-secondary/50 py-20 md:py-28">
        <div className="max-w-3xl mx-auto px-6 md:px-12 text-center">
          <motion.h2
            {...fadeUp}
            className="font-display text-3xl md:text-5xl font-light leading-[1.2] tracking-[0.02em]"
          >
            The beauty in chaos.<br />
            The beauty in what remains.
          </motion.h2>
        </div>
      </section>

      {/* Studio image */}
      <section className="max-w-[1440px] mx-auto px-6 md:px-12 py-16 md:py-24">
        <motion.div
          {...fadeUp}
          className="aspect-[16/9] md:aspect-[21/9] overflow-hidden bg-secondary"
        >
          <img
            src={ATELIER_IMAGE}
            alt="Julissa Arboleda atelier in Houston"
            className="w-full h-full object-cover"
          />
        </motion.div>
      </section>

      {/* Intro text */}
      <section className="max-w-3xl mx-auto px-6 md:px-12 pb-20">
        <motion.p
          {...fadeUp}
          className="font-body text-base md:text-lg text-foreground/80 leading-[1.8] text-center"
        >
          My work is rooted in a simple belief: the things we wear should move with us, soften over time, and honor the materials they're made from.
        </motion.p>
      </section>

      {/* Bio section */}
      <section className="max-w-[1440px] mx-auto px-6 md:px-12 pb-24 md:pb-32">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 md:gap-24">
          <motion.div {...fadeUp}>
            <h2 className="font-display text-3xl md:text-4xl font-light tracking-[0.02em] mb-8">
              Afro-Colombian designer.<br />Houston-based.
            </h2>
            <div className="space-y-6 font-body text-sm text-foreground/80 leading-[1.8]">
              <p>
                I'm Julissa Arboleda, an Afro-Colombian designer creating minimalist, sensual clothing from natural fibers. I studied fashion design at the Art Institute of San Francisco and showed my thesis collection, Suffocation, at New York Fashion Week in 2016.
              </p>
              <p>
                That collection explored depression and anxiety through the lens of institutional care. It taught me that authenticity is the only edit that matters.
              </p>
              <p>
                After working at Louis Vuitton and launching my first collection in 2017, I paused during COVID. In December 2024, I relaunched with a clearer vision: small-batch production, natural fibers, and clothing designed to age beautifully.
              </p>
            </div>
          </motion.div>

          <motion.div {...fadeUp} transition={{ duration: 0.7, delay: 0.2 }}>
            <h2 className="font-display text-3xl md:text-4xl font-light tracking-[0.02em] mb-8">
              Wabi-sabi philosophy.
            </h2>
            <div className="space-y-6 font-body text-sm text-foreground/80 leading-[1.8]">
              <p>
                Wabi-sabi is the Japanese concept of finding beauty in imperfection, impermanence, and incompleteness.
              </p>
              <p>
                In my work, this means designing clothing that embraces wrinkles, values natural texture, and improves with wear. Linen that softens. Hemp that drapes. Cotton that breathes.
              </p>
              <p>
                I don't fight against the way natural fibers behave—I design with it.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Made in Houston */}
      <section className="border-t border-accent/40">
        <div className="max-w-[1440px] mx-auto px-6 md:px-12 py-24 md:py-32">
          <motion.div {...fadeUp} className="max-w-2xl mb-16">
            <h2 className="font-display text-3xl md:text-4xl font-light tracking-[0.02em] mb-6">
              Made in Houston.<br />In small batches.
            </h2>
            <p className="font-body text-sm text-foreground/80 leading-[1.8]">
              Every piece is produced in Houston with a local seamstress. We make 10–50 units per style. Small-batch production means I can maintain quality control, pay fair wages, and avoid the waste that comes with mass manufacturing.
            </p>
          </motion.div>

          <div className="h-[0.5px] bg-accent/40 mb-16" />

          <motion.div {...fadeUp}>
            <h3 className="font-display text-2xl font-light tracking-[0.02em] mb-12">
              What guides this work.
            </h3>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 md:gap-16">
            <motion.div {...fadeUp}>
              <h4 className="font-display text-xl font-light mb-4">Natural Fibers</h4>
              <p className="font-body text-sm text-muted-foreground leading-[1.8]">
                Hemp, organic cotton, linen. Breathable fabrics that age beautifully and feel good against skin.
              </p>
            </motion.div>

            <motion.div {...fadeUp} transition={{ duration: 0.7, delay: 0.15 }}>
              <h4 className="font-display text-xl font-light mb-4">Fair Production</h4>
              <p className="font-body text-sm text-muted-foreground leading-[1.8]">
                Local seamstresses paid fair wages. No exploitative labor. No shortcuts. Quality takes time, and time deserves respect.
              </p>
            </motion.div>

            <motion.div {...fadeUp} transition={{ duration: 0.7, delay: 0.3 }}>
              <h4 className="font-display text-xl font-light mb-4">Intentional Design</h4>
              <p className="font-body text-sm text-muted-foreground leading-[1.8]">
                Every piece is designed to last years, not seasons.
              </p>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
}