import { useQuery } from '@tanstack/react-query';
import { getProducts } from '@/lib/shopify';
import HeroSection from '../components/home/HeroSection';
import FeaturedProducts from '../components/home/FeaturedProducts';
import NyfwSection from '../components/home/NyfwSection';
import NaturalFibers from '../components/home/NaturalFibers';
import CommunitySection from '../components/home/CommunitySection';


export default function Home() {
  const { data: allProducts = [] } = useQuery({
    queryKey: ['all-products'],
    queryFn: getProducts,
    initialData: [],
  });

  const featuredProducts = allProducts.filter(p => p.is_featured);
  const displayProducts = featuredProducts.length > 0 ? featuredProducts : allProducts;

  return (
    <div>
      <HeroSection />
      <FeaturedProducts products={displayProducts} />
      <NyfwSection />
      <NaturalFibers />
      <CommunitySection />
    </div>
  );
}