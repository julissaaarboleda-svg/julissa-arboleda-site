import { useQuery } from '@tanstack/react-query';
import { getProducts } from '@/lib/shopify';
import { motion } from 'framer-motion';
import ProductCard from '../components/products/ProductCard';

export default function Collection() {
  const { data: products = [], isLoading } = useQuery({
    queryKey: ['products-collection'],
    queryFn: getProducts,
    initialData: [],
  });

  return (
    <div className="pt-24 md:pt-28">
      {/* Header */}
      <div className="max-w-[1440px] mx-auto px-6 md:px-12 pt-12 md:pt-20 pb-12">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="font-display text-4xl md:text-5xl lg:text-6xl font-light tracking-[0.02em]"
        >
          Women
        </motion.h1>
        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="h-[0.5px] bg-accent/60 mt-8 origin-left"
        />
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-[11px] font-body text-muted-foreground uppercase tracking-[0.2em] mt-6"
        >
          {products.length} {products.length === 1 ? 'product' : 'products'}
        </motion.p>
      </div>

      {/* Product grid — variable aspect ratio */}
      <div className="max-w-[1440px] mx-auto px-6 md:px-12 pb-24 md:pb-32">
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="aspect-[3/4] bg-secondary" />
                <div className="mt-5 space-y-2">
                  <div className="h-5 bg-secondary w-2/3" />
                  <div className="h-4 bg-secondary w-1/3" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
            {products.map((product, index) => (
              <ProductCard
                key={product.id}
                product={product}
                variant={index === 0 ? 'default' : 'default'}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}