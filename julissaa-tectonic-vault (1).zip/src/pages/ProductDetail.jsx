import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { getProductByHandle } from '@/lib/shopify';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, ChevronLeft, ChevronRight } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import SizeGuide from '../components/products/SizeGuide';

export default function ProductDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const productId = window.location.pathname.split('/product/')[1];
  const navigate = useNavigate();

  const [selectedColor, setSelectedColor] = useState(null);
  const [selectedSize, setSelectedSize] = useState(null);
  const [activeImage, setActiveImage] = useState(0);

  const { data: product, isLoading } = useQuery({
    queryKey: ['product', productId],
    queryFn: () => getProductByHandle(productId),
    enabled: !!productId,
  });

  useEffect(() => {
    if (product) {
      const firstColor = product.colors?.[0] || null;
      setSelectedColor(firstColor);
      if (product.sizes?.length > 0) setSelectedSize(product.sizes[0]);
      // Jump to the image for the first color
      if (firstColor && product.color_image_map?.[firstColor] !== undefined) {
        setActiveImage(product.color_image_map[firstColor]);
      }
    }
  }, [product]);

  if (isLoading) {
    return (
      <div className="pt-24 md:pt-28 min-h-screen">
        <div className="max-w-[1440px] mx-auto px-6 md:px-12 py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-20 animate-pulse">
            <div className="aspect-[3/4] bg-secondary" />
            <div className="space-y-6 pt-8">
              <div className="h-4 bg-secondary w-1/3" />
              <div className="h-10 bg-secondary w-2/3" />
              <div className="h-6 bg-secondary w-1/4" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="pt-24 md:pt-28 min-h-screen flex items-center justify-center">
        <p className="font-display text-xl text-muted-foreground">Product not found</p>
      </div>
    );
  }

  const images = product.images || [];

  return (
    <div className="pt-24 md:pt-28">
      <div className="max-w-[1440px] mx-auto px-6 md:px-12 py-8 md:py-12">
        {/* Back link */}
        <motion.div
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.4 }}
          className="mb-8"
        >
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 text-[11px] font-body font-medium uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-4 h-4" strokeWidth={1.5} />
            Back
          </button>
        </motion.div>

        {/* Sticky scroll layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16 lg:gap-24">
          {/* Left: Image slideshow */}
          <div className="space-y-3">
            {/* Main slide */}
            <div className="relative aspect-[3/4] overflow-hidden bg-secondary">
              <AnimatePresence mode="wait">
                <motion.img
                  key={activeImage}
                  src={images[activeImage]}
                  alt={`${product.name} view ${activeImage + 1}`}
                  initial={{ opacity: 0, x: 40 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -40 }}
                  transition={{ duration: 0.4, ease: [0.25, 0.1, 0.25, 1] }}
                  className="absolute inset-0 w-full h-full object-cover"
                />
              </AnimatePresence>

              {/* Prev / Next arrows */}
              {images.length > 1 && (
                <>
                  <button
                    onClick={() => setActiveImage((prev) => (prev - 1 + images.length) % images.length)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 w-8 h-8 bg-background/80 backdrop-blur-sm flex items-center justify-center hover:bg-background transition-colors"
                  >
                    <ChevronLeft className="w-4 h-4" strokeWidth={1.5} />
                  </button>
                  <button
                    onClick={() => setActiveImage((prev) => (prev + 1) % images.length)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 w-8 h-8 bg-background/80 backdrop-blur-sm flex items-center justify-center hover:bg-background transition-colors"
                  >
                    <ChevronRight className="w-4 h-4" strokeWidth={1.5} />
                  </button>
                </>
              )}

              {/* Dot indicators */}
              {images.length > 1 && (
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-1.5">
                  {images.map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setActiveImage(i)}
                      className={`w-1.5 h-1.5 transition-all duration-300 ${
                        i === activeImage ? 'bg-foreground scale-125' : 'bg-foreground/30'
                      }`}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Thumbnail strip */}
            {images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-1">
                {images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImage(i)}
                    className={`flex-shrink-0 w-16 h-20 overflow-hidden border transition-all duration-200 ${
                      i === activeImage ? 'border-foreground' : 'border-transparent opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right: Product info (sticky) */}
          <div className="md:sticky md:top-32 md:self-start">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="space-y-8"
            >
              <div>
                <p className="text-[11px] font-body font-medium uppercase tracking-[0.2em] text-muted-foreground mb-3">
                  Julissa Arboleda
                </p>
                <h1 className="font-display text-3xl md:text-4xl font-light tracking-[0.02em] mb-4">
                  {product.name}
                </h1>
                <p className="text-lg font-body font-light text-foreground">
                  ${product.price?.toFixed(2)} USD
                </p>
              </div>

              <div className="h-[0.5px] bg-accent/40" />

              {/* Colors */}
              {product.colors && product.colors.length > 0 && (
                <div>
                  <p className="text-[11px] font-body font-medium uppercase tracking-[0.2em] text-muted-foreground mb-4">
                    Color: {selectedColor}
                  </p>
                  <div className="flex gap-3">
                    {product.colors.map((color) => (
                      <button
                        key={color}
                        onClick={() => {
                          setSelectedColor(color);
                          if (product.color_image_map?.[color] !== undefined) {
                            setActiveImage(product.color_image_map[color]);
                          }
                        }}
                        className={`w-8 h-8 border transition-all duration-300 ${
                          selectedColor === color
                            ? 'border-foreground ring-1 ring-foreground ring-offset-2 ring-offset-background'
                            : 'border-accent hover:border-foreground/40'
                        } ${
                          color.toLowerCase() === 'white' ? 'bg-[#F5F5F0]' :
                          color.toLowerCase() === 'black' ? 'bg-[#1a1a1a]' :
                          color.toLowerCase() === 'olive' ? 'bg-[#556B2F]' :
                          'bg-secondary'
                        }`}
                        aria-label={color}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Sizes */}
              {product.sizes && product.sizes.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <p className="text-[11px] font-body font-medium uppercase tracking-[0.2em] text-muted-foreground">
                      Size
                    </p>
                    <SizeGuide />
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {product.sizes.map((size) => (
                      <button
                        key={size}
                        onClick={() => setSelectedSize(size)}
                        className={`px-4 py-2.5 text-[11px] font-body font-medium uppercase tracking-[0.15em] border transition-all duration-300 ${
                          selectedSize === size
                            ? 'bg-foreground text-background border-foreground'
                            : 'bg-transparent text-foreground border-accent hover:border-foreground/40'
                        }`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Add to Cart / Shop on Shopify */}
              <a
                href={product.shopify_url || 'https://julissaa.com'}
                target="_blank"
                rel="noopener noreferrer"
                className={`block w-full py-4 text-center text-[11px] font-body font-medium uppercase tracking-[0.25em] transition-all duration-500 ${
                  product.is_sold_out
                    ? 'bg-secondary text-muted-foreground cursor-not-allowed'
                    : 'bg-primary text-primary-foreground hover:bg-primary/90'
                }`}
              >
                {product.is_sold_out ? 'Sold Out' : 'Add to Cart'}
              </a>

              <div className="h-[0.5px] bg-accent/40" />

              {/* Description */}
              {product.description && (
                <p className="font-body text-sm text-foreground/80 leading-[1.8]">
                  {product.description}
                </p>
              )}

              {/* Fabric & Care */}
              <div className="space-y-4">
                {product.fabric && (
                  <div>
                    <p className="text-sm font-body font-medium text-foreground mb-1">Fabric:</p>
                    <p className="text-sm font-body text-muted-foreground">{product.fabric}</p>
                  </div>
                )}
                {product.inseam && (
                  <div>
                    <p className="text-sm font-body font-medium text-foreground mb-1">Inseam:</p>
                    <p className="text-sm font-body text-muted-foreground">{product.inseam}</p>
                  </div>
                )}
                {product.care && (
                  <div>
                    <p className="text-sm font-body font-medium text-foreground mb-1">Care:</p>
                    <p className="text-sm font-body text-muted-foreground">{product.care}</p>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}